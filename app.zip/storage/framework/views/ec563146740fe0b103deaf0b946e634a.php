<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/app-academy.css')); ?>" />
    <style>
        .badge {
            font-size: 0.85rem;
            padding: 0.4rem 0.75rem;
        }

        .overlay-hover {
            transition: opacity 0.3s ease;
        }

        .card:hover .overlay-hover {
            opacity: 1 !important;
        }

        .content-wrapper i {
            font-size: 1rem;
            vertical-align: middle;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card mb-6">
        <div class="card-header d-flex flex-wrap justify-content-between gap-4">
            <div class="card-title mb-0 me-1">
                <h5 class="mb-0">E-Flayer Marketing</h5>
                <p class="mb-0 text-body">Klik gambar untuk melihat ukuran penuh & download</p>
            </div>
        </div>
        <div class="card-body mt-1">
            <div class="row gy-6 mb-6">
                <?php $__empty_1 = true; $__currentLoopData = $eflayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-6 col-lg-4">
                        <div class="card p-2 h-100 shadow-none border rounded-3">
                            <div class="rounded-4 text-center mb-3 position-relative">
                                <a href="<?php echo e($flayer->picture); ?>" target="_blank" class="d-block"
                                    download="<?php echo e($flayer->name); ?>">
                                    <img class="img-fluid rounded" src="<?php echo e($flayer->picture); ?>" alt="<?php echo e($flayer->name); ?>" />
                                    <div
                                        class="overlay-hover position-absolute top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-center bg-dark bg-opacity-25 rounded opacity-0">
                                        <i class="ri-download-2-line text-white ri-2x"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="card-body p-3 pt-0">
                                <h5 class="mb-3"><?php echo e($flayer->name); ?></h5>
                                <?php if($flayer->content): ?>
                                    <?php
                                        $content = $flayer->formatted_content;
                                    ?>

                                    
                                    <div class="d-flex flex-wrap gap-2 mb-3">
                                        <?php if($content['pesawat']): ?>
                                            <div class="badge bg-label-info">
                                                <i class="ri-plane-line me-1"></i><?php echo e($content['pesawat']); ?>

                                            </div>
                                        <?php endif; ?>
                                        <?php if($content['durasi']): ?>
                                            <div class="badge bg-label-primary">
                                                <i class="ri-time-line me-1"></i><?php echo e($content['durasi']); ?> Hari
                                            </div>
                                        <?php endif; ?>
                                        <?php if($content['tanggal']): ?>
                                            <div class="badge bg-label-success">
                                                <i class="ri-calendar-line me-1"></i><?php echo e($content['tanggal']); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    
                                    <div class="mb-3">
                                        <div class="row g-2">
                                            <?php $__currentLoopData = $content['hotels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-12">
                                                    <div class="d-flex align-items-center">
                                                        <i class="ri-hotel-line me-2"></i>
                                                        <div>
                                                            <small class="text-muted d-block"><?php echo e($hotel['lokasi']); ?></small>
                                                            <span><?php echo e($hotel['nama']); ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>

                                    
                                    <div class="bg-label-primary rounded p-2 mb-3">
                                        <div class="d-flex gap-3">
                                            <div>
                                                <i class="ri-check-line text-primary"></i>
                                                <?php echo e(count($content['fasilitas'])); ?> Fasilitas
                                            </div>
                                            <div>
                                                <i class="ri-information-line text-primary"></i>
                                                Cicilan Tersedia
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <p>Tidak ada e-flayer tersedia saat ini.</p>
                    </div>
                <?php endif; ?>
            </div>

            <?php echo e($eflayers->links('vendor.pagination.custom')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hajj123/public_html/resources/views/pages/marketing-tools/e-flayer.blade.php ENDPATH**/ ?>