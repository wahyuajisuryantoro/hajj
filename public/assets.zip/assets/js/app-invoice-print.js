/**
 * Invoice Print
 */

'use strict';

(function () {
  window.print();
})();
