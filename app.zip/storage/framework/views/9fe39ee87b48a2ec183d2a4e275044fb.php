<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/app-academy.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card mb-6">
        <div class="card-header d-flex flex-wrap justify-content-between gap-4">
            <div class="card-title mb-0 me-1">
                <h5 class="mb-0">Program Umrah</h5>
                <p class="mb-0 text-body">Total <?php echo e($programs->total()); ?> program tersedia</p>
            </div>
            <div class="d-flex justify-content-md-end align-items-center gap-6 flex-wrap">
                <select class="form-select form-select-sm w-px-250" name="category">
                    <option value="">Semua Kategori</option>
                    <option value="regular" <?php echo e(request('category') == 'regular' ? 'selected' : ''); ?>>Regular</option>
                    <option value="plus" <?php echo e(request('category') == 'plus' ? 'selected' : ''); ?>>Plus</option>
                    <option value="vip" <?php echo e(request('category') == 'vip' ? 'selected' : ''); ?>>VIP</option>
                </select>

                <div class="form-check form-switch mb-0">
                    <input type="checkbox" class="form-check-input" id="hidePassedPrograms" name="hide_past" 
                        <?php echo e(request('hide_past') ? 'checked' : ''); ?> />
                    <label class="form-check-label text-nowrap mb-0" for="hidePassedPrograms">Sembunyikan yang sudah lewat</label>
                </div>
            </div>
        </div>
        <div class="card-body mt-1">
            <div class="row gy-6 mb-6">
                <?php $__empty_1 = true; $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-6 col-lg-4">
                        <div class="card p-2 h-100 shadow-none border rounded-3">
                            <div class="rounded-4 text-center mb-5">
                                <img class="img-fluid" src="<?php echo e($program->picture); ?>" 
                                     alt="<?php echo e($program->name); ?>" />
                            </div>
                            <div class="card-body p-3 pt-0">
                                <div class="d-flex justify-content-between align-items-center mb-4">
                                    <span class="badge rounded-pill bg-label-primary"><?php echo e($program->code_category); ?></span>
                                    <p class="d-flex align-items-center justify-content-center fw-medium gap-1 mb-0">
                                        <?php echo e($program->sisa_kursi); ?>/<?php echo e($program->kuota); ?> <span class="text-warning">
                                            <i class="ri-user-line ri-24px me-1"></i>
                                        </span>
                                    </p>
                                </div>
                                <a href="<?php echo e(route('member.program.show', $program->code)); ?>" class="h5"><?php echo e($program->name); ?></a>
                                <p class="mt-1"><?php echo e(Str::limit($program->desc, 100)); ?></p>
                                <p class="d-flex align-items-center mb-1">
                                    <i class="ri-time-line ri-20px me-1"></i><?php echo e($program->duration); ?> Hari
                                </p>
                                <p class="d-flex align-items-center mb-1">
                                    <i class="ri-calendar-line ri-20px me-1"></i><?php echo e($program->formatted_tanggal_berangkat); ?>

                                </p>
                                <p class="h5 mb-4"><?php echo e($program->formatted_price); ?></p>
                                
                                <div class="d-flex flex-column flex-md-row gap-4 text-nowrap">
                                    <a class="w-100 btn btn-outline-primary d-flex align-items-center"
                                        href="<?php echo e(route('member.program.show', $program->code)); ?>">
                                        <span class="me-2">Detail Program</span>
                                        <i class="ri-arrow-right-line ri-16px lh-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <p>Tidak ada program yang tersedia saat ini.</p>
                    </div>
                <?php endif; ?>
            </div>
            
           
        </div>
    </div>
    <?php echo e($programs->links('vendor.pagination.custom')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Handle category filter change
            const categorySelect = document.querySelector('select[name="category"]');
            categorySelect.addEventListener('change', function() {
                updateFilters();
            });

            // Handle hide past programs toggle
            const hidePastCheckbox = document.querySelector('input[name="hide_past"]');
            hidePastCheckbox.addEventListener('change', function() {
                updateFilters();
            });

            function updateFilters() {
                const category = categorySelect.value;
                const hidePast = hidePastCheckbox.checked;
                
                let url = new URL(window.location.href);
                url.searchParams.set('category', category);
                url.searchParams.set('hide_past', hidePast ? '1' : '');
                
                window.location.href = url.toString();
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hajj123/public_html/resources/views/pages/program/index.blade.php ENDPATH**/ ?>