<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/jstree/jstree.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12 col-12">
        <div class="card mb-12">
            <h5 class="card-header"><?php echo e($title); ?></h5>
            <div class="card-body">
                <div id="jstree-mitra"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/vendor/libs/jstree/jstree.js')); ?>"></script>
    <script>
        $(function() {
            var theme = $('html').hasClass('light-style') ? 'default' : 'default-dark';
            var mitraTree = $('#jstree-mitra');

            if (mitraTree.length) {
                mitraTree.jstree({
                    core: {
                        themes: {
                            name: theme
                        },
                        data: <?php echo json_encode($tree, 15, 512) ?>
                    },
                    plugins: ['types'],
                    types: {
                        'default': {
                            'icon': 'ri-user-line'
                        },
                        'leader': {
                            'icon': 'ri-user-star-line text-warning'
                        }
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hajj123/public_html/resources/views/pages/mitra/genealogy.blade.php ENDPATH**/ ?>