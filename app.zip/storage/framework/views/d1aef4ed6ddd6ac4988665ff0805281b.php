Attached you will find requested report.
<?php /**PATH /home/hajj123/public_html/vendor/yajra/laravel-datatables-export/src/resources/views/export-email.blade.php ENDPATH**/ ?>