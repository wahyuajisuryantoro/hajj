<?php $__env->startSection('account-content'); ?>
    <div class="card mb-6">
        <h5 class="card-header mb-2">Perbarui Foto Profil Anda</h5>
        <div class="card-body pt-0">
            <form id="formProfilePicture" method="POST" enctype="multipart/form-data"
                action="<?php echo e(route('account.update-profile-picture')); ?>">
                <?php echo csrf_field(); ?>
                <div class="d-flex align-items-start align-items-sm-center gap-6">
                    <img src="<?php echo e($mitra->picture_profile ? $mitra->picture_profile : asset('assets/img/avatars/1.png')); ?>"
                        alt="user-avatar" class="d-block w-px-100 h-px-100 rounded-4" id="uploadedAvatarPreview" />
                    <div class="button-wrapper">
                        <label for="uploadPicture" class="btn btn-primary me-3 mb-4" tabindex="0">
                            <span class="d-none d-sm-block">Pilih Foto Baru</span>
                            <i class="ri-upload-2-line d-block d-sm-none"></i>
                            <input type="file" id="uploadPicture"
                                class="account-file-input <?php $__errorArgs = ['picture_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="picture_profile" hidden accept="image/png, image/jpeg, image/jpg" />
                        </label>
                        
                        <div>Format File Wajib JPG, JPEG, PNG. Ukuran Maksimal 2MB</div>
                        <?php $__errorArgs = ['picture_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-success save-picture-btn" disabled>Save Photo</button>
                </div>
            </form>
        </div>
    </div>
    <div class="card mb-6">
        <h5 class="card-header mb-1">Perbarui Informasi Dasar Akun Anda</h5>
        <div class="card-body pt-0">
            <form id="formAccountSettings" method="POST" action="<?php echo e(route('account.update-profile')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row mt-1 g-5">
                    <!-- Nama -->
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input class="form-control" type="text" id="name" name="name"
                                value="<?php echo e(old('name', $mitra->name)); ?>" required autofocus />
                            <label for="name">Name</label>
                        </div>
                    </div>
                    <!-- Email -->
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input class="form-control" type="email" name="email" id="email"
                                value="<?php echo e(old('email', $mitra->email)); ?>" required />
                            <label for="email">E-mail</label>
                        </div>
                    </div>
                    <!-- Nomor Telepon -->
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" class="form-control" id="phone" name="phone"
                                value="<?php echo e(old('phone', $mitra->phone)); ?>" required />
                            <label for="phone">Phone Number</label>
                        </div>
                    </div>
                    <!-- Tempat Lahir -->
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" class="form-control" id="birth_place" name="birth_place"
                                value="<?php echo e(old('birth_place', $mitra->birth_place)); ?>" required />
                            <label for="birth_place">Birth Place</label>
                        </div>
                    </div>
                    <!-- Tanggal Lahir -->
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input class="form-control" type="date" id="birth_date" name="birth_date"
                                value="<?php echo e(old('birth_date', $mitra->birth_date ? \Carbon\Carbon::parse($mitra->birth_date)->format('Y-m-d') : '')); ?>"
                                required />
                            <label for="birth_date">Birth Date</label>
                            <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Alamat -->
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <textarea class="form-control" id="address" name="address" required><?php echo e(old('address', $mitra->address)); ?></textarea>
                            <label for="address">Address</label>
                        </div>
                    </div>
                </div>
                <div class="mt-6">
                    <button type="submit" class="btn btn-primary me-3 save-basic-btn" disabled>Save changes</button>
                    
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.account.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hajj123/public_html/resources/views/pages/account/content/account.blade.php ENDPATH**/ ?>