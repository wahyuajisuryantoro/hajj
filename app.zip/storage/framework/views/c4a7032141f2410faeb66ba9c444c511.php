<?php $__env->startSection('account-content'); ?>
    <!-- Form Edit Bank -->
    <div class="card mb-6">
        <div class="card-header">
            Edit Informasi Bank
        </div>
        <div class="card-body pt-0">
            <!-- Tampilkan Alert di sini jika ada -->
            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form id="formEditBank" method="POST" action="<?php echo e(route('account.update-bank')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row g-5">
                    <!-- Nama Bank -->
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select class="form-select <?php $__errorArgs = ['bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bank" name="bank" required>
                                <option value="">Pilih Bank</option>
                                <option value="BCA" <?php echo e(old('bank', $mitra->bank) == 'BCA' ? 'selected' : ''); ?>>BCA</option>
                                <option value="BNI" <?php echo e(old('bank', $mitra->bank) == 'BNI' ? 'selected' : ''); ?>>BNI</option>
                                <option value="Mandiri" <?php echo e(old('bank', $mitra->bank) == 'Mandiri' ? 'selected' : ''); ?>>Mandiri</option>
                                <option value="BRI" <?php echo e(old('bank', $mitra->bank) == 'BRI' ? 'selected' : ''); ?>>BRI</option>
                                <!-- Tambahkan opsi bank lainnya sesuai kebutuhan -->
                            </select>
                            <label for="bank">Nama Bank</label>
                            <?php $__errorArgs = ['bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Nomor Rekening -->
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" class="form-control <?php $__errorArgs = ['bank_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bank_number" name="bank_number" value="<?php echo e(old('bank_number', $mitra->bank_number)); ?>" required />
                            <label for="bank_number">Nomor Rekening</label>
                            <?php $__errorArgs = ['bank_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Nama Pemilik Rekening -->
                    <div class="col-md-12">
                        <div class="form-floating form-floating-outline">
                            <input type="text" class="form-control <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bank_name" name="bank_name" value="<?php echo e(old('bank_name', $mitra->bank_name)); ?>" required />
                            <label for="bank_name">Nama Pemilik Rekening</label>
                            <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="mt-6">
                    <button type="submit" class="btn btn-primary save-bank-btn" disabled>Save Changes</button>
                    <button type="reset" class="btn btn-outline-secondary reset-bank-btn">Reset</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('pages.account.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hajj123/public_html/resources/views/pages/account/content/bank.blade.php ENDPATH**/ ?>