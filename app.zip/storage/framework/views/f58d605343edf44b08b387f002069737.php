<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card mb-4">
            <h5 class="card-header">Pendaftaran Customer Baru</h5>
            <form class="card-body" method="POST" action="<?php echo e(route('customer.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h6>1. Informasi Akun</h6>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="username" name="username" class="form-control" placeholder="john.doe"
                                value="<?php echo e(old('username')); ?>" required />
                            <label for="username">Username</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="email" id="email" name="email" class="form-control"
                                placeholder="john@example.com" value="<?php echo e(old('email')); ?>" />
                            <label for="email">Email</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-password-toggle">
                            <div class="input-group input-group-merge">
                                <div class="form-floating form-floating-outline">
                                    <input type="password" id="password" name="password" class="form-control" />
                                    <label for="password">Password</label>
                                </div>
                                <span class="input-group-text cursor-pointer"><i class="ri-eye-off-line"></i></span>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="my-4 mx-n4" />
                <h6>2. Data Pribadi</h6>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="name" name="name" class="form-control" placeholder="Nama Lengkap"
                                value="<?php echo e(old('name')); ?>" required />
                            <label for="name">Nama Lengkap</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="NIK" name="NIK" class="form-control" placeholder="1234567890123456"
                                value="<?php echo e(old('NIK')); ?>" required />
                            <label for="NIK">NIK</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select id="sex" name="sex" class="form-select" required>
                                <option value="">Pilih Jenis Kelamin</option>
                                <option value="L" <?php echo e(old('sex') == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                                <option value="P" <?php echo e(old('sex') == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                            </select>
                            <label for="sex">Jenis Kelamin</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="birth_place" name="birth_place" class="form-control"
                                placeholder="Tempat Lahir" value="<?php echo e(old('birth_place')); ?>" />
                            <label for="birth_place">Tempat Lahir</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="birth_date" name="birth_date" class="form-control flatpickr"
                                placeholder="YYYY-MM-DD" value="<?php echo e(old('birth_date')); ?>" />
                            <label for="birth_date">Tanggal Lahir</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="phone" name="phone" class="form-control phone-mask"
                                placeholder="6285700154847" value="<?php echo e(old('phone')); ?>" required />
                            <label for="phone">No. Telepon</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-floating form-floating-outline">
                            <textarea class="form-control" id="address" name="address" rows="3"
                                placeholder="Alamat Lengkap"><?php echo e(old('address')); ?></textarea>
                            <label for="address">Alamat Lengkap</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select id="code_province" name="code_province" class="form-select">
                                <option value="">Pilih Provinsi</option>
                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($province->code); ?>"
                                        <?php echo e(old('code_province') == $province->code ? 'selected' : ''); ?>>
                                        <?php echo e($province->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="code_province">Provinsi</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select id="code_city" name="code_city" class="form-select">
                                <option value="">Pilih Kota/Kabupaten</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->code); ?>"
                                        <?php echo e(old('code_city') == $city->code ? 'selected' : ''); ?>>
                                        <?php echo e($city->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="code_city">Kota/Kabupaten</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select id="code_cabang" name="code_cabang" class="form-select">
                                <option value="">Pilih Cabang</option>
                                <?php $__currentLoopData = $cabangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cabang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cabang->code); ?>"
                                        <?php echo e(old('code_cabang') == $cabang->code ? 'selected' : ''); ?>>
                                        <?php echo e($cabang->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="code_cabang">Cabang</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="code_mitra" name="code_mitra" class="form-control" readonly
                                value="<?php echo e(Auth::guard('mitra')->user()->code); ?>" />
                            <label for="code_mitra">Mitra Pengaju</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select id="status_prospek" name="status_prospek" class="form-select" required>
                                <option value="">Pilih Status Prospek</option>
                                <option value="cold" <?php echo e(old('status_prospek') == 'cold' ? 'selected' : ''); ?>>Cold</option>
                                <option value="warm" <?php echo e(old('status_prospek') == 'warm' ? 'selected' : ''); ?>>Warm</option>
                                <option value="hot" <?php echo e(old('status_prospek') == 'hot' ? 'selected' : ''); ?>>Hot</option>
                            </select>
                            <label for="status_prospek">Status Prospek</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select id="code_category" name="code_category" class="form-select">
                                <option value="">Pilih Kategori</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->code); ?>"
                                        <?php echo e(old('code_category') == $category->code ? 'selected' : ''); ?>>
                                        <?php echo e($category->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="code_category">Kategori</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <select id="code_program" name="code_program" class="form-select">
                                <option value="">Pilih Program</option>
                                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($program->code); ?>"
                                        <?php echo e(old('code_program') == $program->code ? 'selected' : ''); ?>>
                                        <?php echo e($program->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="code_program">Program</label>
                        </div>
                    </div>
                </div>

                <hr class="my-4 mx-n4" />
                <h6>3. Dokumen</h6>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-floating form-floating-outline">
                            <input type="file" id="picture_ktp" name="picture_ktp" class="form-control"
                                accept="image/*" required />
                            <label for="picture_ktp">Foto KTP</label>
                            <?php if(session('errors') && session('errors')->has('picture_ktp')): ?>
                                <div class="text-danger mt-1">
                                    <?php echo e(session('errors')->first('picture_ktp')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="pt-4">
                    <button type="submit" class="btn btn-primary me-sm-3 me-1">Submit</button>
                    <button type="reset" class="btn btn-label-secondary">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Optional: Modal atau komponen tambahan dapat ditambahkan di sini -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Vendors JS -->
    <script src="<?php echo e(asset('assets/vendor/libs/cleavejs/cleave.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/cleavejs/cleave-phone.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/flatpickr/flatpickr.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/select2/select2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/form-layouts.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            // Initialize Flatpickr
            $('.flatpickr').flatpickr({
                dateFormat: "Y-m-d"
            });

            // Initialize Select2
            $('.select-select2').select2({
                placeholder: "Pilih opsi",
                allowClear: true
            });

            // Initialize phone mask
            new Cleave('.phone-mask', {
                phone: true,
                phoneRegionCode: 'ID'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hajj123/public_html/resources/views/pages/customer/pendaftaran.blade.php ENDPATH**/ ?>