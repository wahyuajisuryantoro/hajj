<ul>
    <li>
        <div class="mitra-node <?php if($node['code_mitra'] === null): ?> parent-node <?php endif; ?> <?php if($loop->first ?? false): ?> current-user <?php endif; ?>">
            <?php if(!empty($node['picture_profile'])): ?>
                <img src="<?php echo e(asset('storage/' . $node['picture_profile'])); ?>" alt="<?php echo e($node['name']); ?>" class="mitra-image">
            <?php else: ?>
                <div class="mitra-image" style="background-color: #007bff; display: flex; align-items: center; justify-content: center; color: white;">
                    <?php echo e(strtoupper(substr($node['name'], 0, 1))); ?>

                </div>
            <?php endif; ?>
        </div>
        <?php if(!empty($node['children'])): ?>
            <?php $__currentLoopData = $node['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('pages.mitra.tree_node', ['node' => $child], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </li>
</ul><?php /**PATH /home/hajj123/public_html/resources/views/pages/mitra/tree_node.blade.php ENDPATH**/ ?>