<?php $__env->startSection('content'); ?>
    <div class="row g-6">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center flex-wrap mb-6 gap-1">
                        <div class="me-1">
                            <h5 class="mb-0"><?php echo e($program->name); ?></h5>
                            <p class="mb-0">Kode Program: <span class="fw-medium text-heading"><?php echo e($program->code); ?></span></p>
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="badge bg-label-primary rounded-pill"><?php echo e($program->code_category); ?></span>
                            <a href="<?php echo e(route('member.program')); ?>" class="btn btn-outline-primary ms-4">
                                <i class="ri-arrow-left-line ri-24px"></i> Kembali
                            </a>
                        </div>
                    </div>
                    <div class="card academy-content shadow-none border">
                        <div class="p-2">
                            <div class="cursor-pointer">
                                <img src="<?php echo e($program->picture); ?>" 
                                     alt="<?php echo e($program->name); ?>"
                                     class="w-100 rounded"
                                     style="max-height: 600px; object-fit: cover;">
                            </div>
                        </div>
                        <div class="card-body pt-3">
                            <?php
                                $formatted_desc = $program->formatted_desc;
                            ?>
                            
                            
                            <div class="d-flex flex-wrap gap-3 mb-4">
                                <?php if($formatted_desc['pesawat']): ?>
                                <div class="badge bg-label-info">
                                    <i class="ri-plane-line me-1"></i>
                                    <?php echo e($formatted_desc['pesawat']); ?>

                                </div>
                                <?php endif; ?>
                                <?php if($formatted_desc['durasi']): ?>
                                <div class="badge bg-label-primary">
                                    <i class="ri-time-line me-1"></i>
                                    <?php echo e($formatted_desc['durasi']); ?> Hari
                                </div>
                                <?php endif; ?>
                            </div>

                            
                            <div class="mb-4">
                                <h5 class="mb-3">Akomodasi Hotel</h5>
                                <div class="row g-3">
                                    <?php $__currentLoopData = $formatted_desc['hotels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="p-3 border rounded">
                                            <p class="fw-medium mb-1"><?php echo e($hotel['lokasi']); ?></p>
                                            <p class="mb-0 text-muted">
                                                <i class="ri-hotel-line me-2"></i><?php echo e($hotel['nama']); ?>

                                            </p>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            
                            <?php if(count($formatted_desc['fasilitas']) > 0): ?>
                            <div class="mb-4">
                                <h5 class="mb-3">Fasilitas Program</h5>
                                <div class="row g-3">
                                    <?php $__currentLoopData = array_chunk($formatted_desc['fasilitas'], ceil(count($formatted_desc['fasilitas'])/2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <ul class="list-unstyled mb-0">
                                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fasilitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="mb-2">
                                                <i class="ri-check-line text-success me-2"></i><?php echo e($fasilitas); ?>

                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php endif; ?>

                            
                            <?php if(count($formatted_desc['non_fasilitas']) > 0): ?>
                            <div class="mb-4">
                                <h5 class="mb-3">Tidak Termasuk</h5>
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $formatted_desc['non_fasilitas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="mb-2">
                                        <i class="ri-close-line text-danger me-2"></i><?php echo e($item); ?>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <?php if(count($formatted_desc['pembayaran']) > 0): ?>
                            <div class="bg-label-primary p-4 rounded">
                                <h5 class="mb-3">Ketentuan Pembayaran</h5>
                                <ul class="list-unstyled mb-0">
                                    <?php $__currentLoopData = $formatted_desc['pembayaran']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketentuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="mb-2">
                                        <i class="ri-secure-payment-line me-2"></i><?php echo e($ketentuan); ?>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            <hr class="my-6" />
                            
                            <h5>Informasi Program</h5>
                            <div class="d-flex flex-wrap row-gap-2">
                                <div class="me-12">
                                    <p class="text-nowrap mb-2">
                                        <i class="ri-calendar-line ri-20px me-2"></i>Keberangkatan: <?php echo e($program->formatted_tanggal_berangkat); ?>

                                    </p>
                                    <p class="text-nowrap mb-2">
                                        <i class="ri-time-line ri-20px me-2"></i>Durasi: <?php echo e($program->duration); ?> Hari
                                    </p>
                                    <p class="text-nowrap mb-2">
                                        <i class="ri-map-pin-line ri-20px me-2"></i>Kota: <?php echo e($program->code_city); ?>

                                    </p>
                                </div>
                                <div>
                                    <p class="text-nowrap mb-2">
                                        <i class="ri-group-line ri-20px me-2"></i>Kuota: <?php echo e($program->kuota); ?> Jamaah
                                    </p>
                                    <p class="text-nowrap mb-2">
                                        <i class="ri-user-line ri-20px me-2"></i>Sisa Kursi: <?php echo e($program->sisa_kursi); ?>

                                    </p>
                                    <p class="text-nowrap mb-0">
                                        <i class="ri-money-dollar-circle-line ri-20px me-2"></i>Harga: <?php echo e($program->formatted_price); ?>

                                    </p>
                                </div>
                            </div>

                            <hr class="my-6" />

                            <div class="d-grid gap-2">
                                <?php if($program->sisa_kursi > 0): ?>
                                    <p class="text-center text-success mb-0">
                                        <i class="ri-checkbox-circle-line me-1"></i>Masih tersedia <?php echo e($program->sisa_kursi); ?> kursi
                                    </p>
                                <?php else: ?>
                                    <p class="text-center text-danger mb-0">
                                        <i class="ri-error-warning-line me-1"></i>Kuota sudah penuh
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hajj123/public_html/resources/views/pages/program/show.blade.php ENDPATH**/ ?>